love.graphics.setDefaultFilter("nearest", "nearest")

local sprites = {
    gummi = love.graphics.newImage("assets/sprites/gummi.png"),
}

return sprites